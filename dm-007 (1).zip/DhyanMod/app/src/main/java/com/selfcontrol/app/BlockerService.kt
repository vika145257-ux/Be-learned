package com.selfcontrol.app

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.VideoView

/**
 * चुने हुए ऐप के सामने खुलते ही पूरी स्क्रीन पर वीडियो की परत (overlay) लगा देता है।
 * परत Accessibility सर्विस की अपनी window है, इसलिए पॉप-अप या Autostart की अलग इजाज़त नहीं लगती।
 *
 * स्क्रीन का टेक्स्ट/डेटा न पढ़ता है, न सेव करता है। ऐप में INTERNET की इजाज़त भी नहीं है।
 *
 * वीडियो के दौरान टच बंद, Home दबाने पर भी परत नहीं हटती। फ़ोन फँसे नहीं, इसलिए:
 *  1) अधिकतम 5 मिनट
 *  2) कॉल आए/चल रही हो तो परत हट जाती है
 *  3) वॉल्यूम-डाउन 5 सेकंड दबाए रखो तो परत हट जाती है
 *  4) पावर बटन से स्क्रीन बंद करो तो परत हट जाती है
 *  5) वीडियो में एरर आए तो परत हट जाती है
 */
class BlockerService : AccessibilityService() {

    companion object {
        private const val HARD_CAP_MS = 5 * 60 * 1000L
        private const val NO_VIDEO_MS = 15_000L
        private const val ESCAPE_MS = 5_000L
        private const val GRACE_MS = 4_000L

        @Volatile
        var instance: BlockerService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var overlay: FrameLayout? = null
    private var video: VideoView? = null
    private var counter: TextView? = null
    private var pendingPkg: String? = null
    private var tries = 0
    private var lastVideo: String? = null
    private var endsAt = 0L
    private var receiverOn = false
    private var tickCount = 0
    private var awayTries = 0
    private var awayClean = 0
    private var started = false
    private var lastEnd = 0L

    // चुने हुए ऐप का event आया: सच में वही ऐप सामने है तभी वीडियो चलाओ (होम/लॉक स्क्रीन पर नहीं)
    private val verify = Runnable {
        val pkg = pendingPkg ?: return@Runnable
        if (overlay != null || isLocked() || inCall()) return@Runnable
        val front = rootInActiveWindow?.packageName?.toString()
        when {
            front == pkg -> showOverlay()
            // सामने वाली window पढ़ी नहीं जा सकी: दो बार दोबारा देखो, फिर भी न मिले तो चला दो
            front == null && tries >= 2 -> showOverlay()
            // कोई और ऐप / होम सामने है: क़रीब 2 सेकंड इंतज़ार, फिर छोड़ दो
            tries < 24 -> {
                if (tries == 0) Diag.note("$pkg: सामने $front है, इंतज़ार")
                tries++
                schedule(pkg, 150)
            }
            else -> Diag.note("$pkg: सामने $front ही रहा, वीडियो नहीं चलाई")
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (overlay == null) return
            if (inCall()) {
                Diag.note("ऑडियो-मोड बदला (mode=${audioMode()}): वीडियो परत हटाई")
                hideOverlay(false)
                return
            }
            val v = video
            val leftMs: Long = if (v != null && v.duration > 0) {
                (v.duration - v.currentPosition).toLong()
            } else {
                endsAt - SystemClock.uptimeMillis()
            }
            val sec = leftMs.coerceAtLeast(0L) / 1000 + 1
            counter?.text = "बचा हुआ समय: $sec सेकंड\nइमरजेंसी: वॉल्यूम-डाउन 5 सेकंड दबाए रखो"
            // हर 1 सेकंड में देखो: चुना हुआ ऐप पीछे सामने तो नहीं आ गया (उसकी आवाज़ न चले)
            tickCount++
            if (tickCount % 2 == 0) {
                val front = rootInActiveWindow?.packageName?.toString()
                if (front != null && front in Prefs.blocked(this@BlockerService)) {
                    performGlobalAction(GLOBAL_ACTION_HOME)
                }
            }
            handler.postDelayed(this, 500)
        }
    }

    // वीडियो हटने के बाद: चुना हुआ ऐप अब भी सामने हो तो फिर होम भेजो (पहले होम बटन, फिर होम का सीधा intent)
    private val away = Runnable {
        if (overlay != null || isLocked() || inCall()) return@Runnable
        val front = rootInActiveWindow?.packageName?.toString()
        if (front != null && front in Prefs.blocked(this)) {
            // चुना हुआ ऐप फिर सामने है: दोबारा होम भेजो
            awayClean = 0
            awayTries++
            Diag.note("वीडियो के बाद $front सामने था, होम भेजा (कोशिश $awayTries)")
            if (awayTries <= 2) performGlobalAction(GLOBAL_ACTION_HOME) else goHomeIntent()
        } else {
            awayClean++
        }
        // लगातार 3 बार (करीब 1.5 सेकंड) ऐप सामने न दिखे तब तक देखते रहो; हद 20 कोशिश
        if (awayClean < 3 && awayTries < 20) scheduleAway(500)
    }

    private fun scheduleAway(delayMs: Long) {
        handler.removeCallbacks(away)
        handler.postDelayed(away, delayMs)
    }

    private val endNow = Runnable { hideOverlay(true) }

    // वीडियो 8 सेकंड में शुरू न हो (खराब फ़ाइल वगैरह) तो परत न अटके
    private val startCheck = Runnable {
        if (overlay != null && video != null && !started) {
            Diag.note("वीडियो 8 सेकंड में शुरू नहीं हुई, परत हटाई")
            hideOverlay(true)
        }
    }
    private val escape = Runnable { hideOverlay(true) }

    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            hideOverlay(false)
        }
    }

    private fun schedule(pkg: String, delayMs: Long) {
        pendingPkg = pkg
        handler.removeCallbacks(verify)
        handler.postDelayed(verify, delayMs)
    }

    private fun isLocked(): Boolean {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        return km.isKeyguardLocked
    }

    private fun goHomeIntent() {
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_HOME)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
        }
    }

    private fun audioMode(): Int =
        (getSystemService(Context.AUDIO_SERVICE) as AudioManager).mode

    /** ऐप के "टेस्ट" बटन से: वीडियो परत अभी चलाकर देखो */
    fun testOverlay() {
        handler.post {
            if (overlay == null) {
                Diag.note("टेस्ट बटन से वीडियो परत चलाई")
                showOverlay()
            }
        }
    }

    private fun inCall(): Boolean {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val m = am.mode
        return m == AudioManager.MODE_RINGTONE ||
                m == AudioManager.MODE_IN_CALL ||
                m == AudioManager.MODE_IN_COMMUNICATION
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Diag.connected = true
        Diag.note("सर्विस जुड़ी")
        if (!receiverOn) {
            val f = IntentFilter(Intent.ACTION_SCREEN_OFF)
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(screenOff, f, Context.RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(screenOff, f)
            }
            receiverOn = true
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        Diag.seen(pkg)
        if (overlay != null) return
        if (pkg !in Prefs.blocked(this)) return
        Diag.hit(pkg)
        // वीडियो अभी खत्म हुई है: यह उसी ऐप की बची-खुची हलचल है, नई वीडियो नहीं, बस फिर होम भेजो
        if (SystemClock.uptimeMillis() - lastEnd < GRACE_MS) {
            Diag.note("$pkg: वीडियो अभी खत्म हुई थी, फिर होम भेजा")
            performGlobalAction(GLOBAL_ACTION_HOME)
            scheduleAway(500)
            return
        }
        if (isLocked()) {
            Diag.note("$pkg: फ़ोन लॉक माना गया, वीडियो नहीं चलाई")
            return
        }
        if (inCall()) {
            Diag.note("$pkg: कॉल/ऑडियो-मोड माना गया (mode=${audioMode()}), वीडियो नहीं चलाई")
            return
        }
        tries = 0
        schedule(pkg, 0)
    }

    private fun showOverlay() {
        if (overlay != null) return
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        handler.removeCallbacks(away)
        tickCount = 0
        started = false
        val density = resources.displayMetrics.density
        fun px(v: Int) = (v * density).toInt()

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        root.isClickable = true // सारे टच यहीं रुक जाएँगे

        val now = SystemClock.uptimeMillis()
        val files = Prefs.videos(this)
        if (files.isNotEmpty()) {
            val choices = if (files.size > 1) files.filter { it.name != lastVideo } else files
            val f = choices.random()
            lastVideo = f.name
            endsAt = now + HARD_CAP_MS
            val v = VideoView(this)
            video = v
            root.addView(
                v,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    Gravity.CENTER
                )
            )
            v.setOnPreparedListener {
                started = true
                v.start()
            }
            v.setOnCompletionListener { hideOverlay(true) }
            v.setOnErrorListener { _, _, _ ->
                hideOverlay(true)
                true
            }
            v.setVideoPath(f.absolutePath)
            handler.postDelayed(startCheck, 8000)
        } else {
            // वीडियो नहीं जोड़ी तो 15 सेकंड का टेक्स्ट
            endsAt = now + NO_VIDEO_MS
            handler.postDelayed(endNow, NO_VIDEO_MS)
        }

        val title = TextView(this)
        title.text = "ध्यान मोड़ 💪"
        title.setTextColor(Color.WHITE)
        title.textSize = 24f
        title.gravity = Gravity.CENTER
        title.setPadding(px(16), px(48), px(16), px(16))
        root.addView(
            title,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP
            )
        )

        val c = TextView(this)
        c.setTextColor(Color.parseColor("#CCCCCC"))
        c.textSize = 14f
        c.gravity = Gravity.CENTER
        c.setPadding(px(16), px(16), px(16), px(48))
        root.addView(
            c,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            )
        )
        counter = c

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.OPAQUE
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        try {
            wm.addView(root, lp)
        } catch (e: Exception) {
            Diag.note("परत लगाने में एरर: ${e.javaClass.simpleName}: ${e.message}")
            video = null
            counter = null
            return
        }
        overlay = root
        Diag.shown++
        Diag.note("वीडियो परत लगाई")

        // असली ऐप को पीछे होम पर भेज दो, ताकि उसकी आवाज़/वीडियो न चले
        performGlobalAction(GLOBAL_ACTION_HOME)

        handler.post(tick)
        // पूरे सेशन की हद
        handler.postDelayed(endNow, HARD_CAP_MS)
    }

    private fun hideOverlay(goHome: Boolean) {
        if (overlay != null) Diag.note("परत हटी (होम भेजना=$goHome)")
        handler.removeCallbacks(tick)
        handler.removeCallbacks(endNow)
        handler.removeCallbacks(startCheck)
        handler.removeCallbacks(escape)
        handler.removeCallbacks(verify)
        val o = overlay
        overlay = null
        if (o != null) {
            try {
                video?.stopPlayback()
            } catch (e: Exception) {
            }
            try {
                (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(o)
            } catch (e: Exception) {
            }
        }
        video = null
        counter = null
        if (goHome && o != null) {
            lastEnd = SystemClock.uptimeMillis()
            performGlobalAction(GLOBAL_ACTION_HOME)
            // पक्का करो कि चुना हुआ ऐप सामने न रह जाए
            awayTries = 0
            awayClean = 0
            scheduleAway(500)
        }
    }

    // वॉल्यूम-डाउन 5 सेकंड दबाए रखो: इमरजेंसी एग्ज़िट
    override fun onKeyEvent(event: KeyEvent?): Boolean {
        if (event != null && overlay != null && event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                if (event.repeatCount == 0) {
                    handler.removeCallbacks(escape)
                    handler.postDelayed(escape, ESCAPE_MS)
                }
            } else if (event.action == KeyEvent.ACTION_UP) {
                handler.removeCallbacks(escape)
            }
        }
        return false
    }

    override fun onInterrupt() {
        // वीडियो बीच में न कटे, इसलिए यहाँ परत नहीं हटाते; सिर्फ़ जाँच के लिए नोट
        Diag.note("सिस्टम ने onInterrupt भेजा (अनदेखा किया)")
    }

    override fun onDestroy() {
        Diag.connected = false
        if (instance === this) instance = null
        handler.removeCallbacks(away)
        hideOverlay(false)
        if (receiverOn) {
            try {
                unregisterReceiver(screenOff)
            } catch (e: Exception) {
            }
            receiverOn = false
        }
        super.onDestroy()
    }
}
