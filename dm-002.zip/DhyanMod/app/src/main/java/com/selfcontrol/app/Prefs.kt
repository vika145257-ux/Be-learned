package com.selfcontrol.app

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import java.io.File

data class AppItem(val label: String, val pkg: String, val icon: Drawable)

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/**
 * सेटिंग और वीडियो फ़ोन के अंदर ही रहते हैं।
 * वीडियो बीच में काटी नहीं जा सकती (uncuttable): सिर्फ़ 5 मिनट की हद, कॉल, या वॉल्यूम-डाउन 5 सेकंड से खुलती है।
 */
object Prefs {
    private val DEFAULT_BLOCKED = setOf(
        "com.instagram.android",
        "com.google.android.youtube",
        "com.android.chrome"
    )

    private fun sp(c: Context) = c.getSharedPreferences("selfcontrol", Context.MODE_PRIVATE)

    fun blocked(c: Context): Set<String> =
        sp(c).getStringSet("blocked", null)?.toSet() ?: DEFAULT_BLOCKED

    fun setBlocked(c: Context, s: Set<String>) =
        sp(c).edit().putStringSet("blocked", HashSet(s)).apply()

    fun videoDir(c: Context): File = File(c.filesDir, "videos")

    fun videos(c: Context): List<File> =
        videoDir(c).listFiles()
            ?.filter { it.isFile && it.length() > 0 }
            ?.sortedBy { it.name }
            ?: emptyList()

    fun clearVideos(c: Context) {
        videoDir(c).listFiles()?.forEach { it.delete() }
    }
}

object Apps {
    /** जाने-पहचाने सोशल/वीडियो ऐप। बाकी ऐप "और ऐप चुनो" से जुड़ते हैं। */
    private val KNOWN = setOf(
        "com.instagram.android",
        "com.instagram.lite",
        "com.google.android.youtube",
        "com.google.android.googlequicksearchbox",
        "com.facebook.katana",
        "com.facebook.lite",
        "com.snapchat.android",
        "com.twitter.android",
        "com.reddit.frontpage",
        "in.mohalla.sharechat",
        "in.mohalla.video",
        "org.telegram.messenger"
    )

    /** फ़ोन के सभी launcher ऐप (अपने को छोड़कर), नाम से sorted */
    fun launchable(c: Context): List<AppItem> {
        val pm = c.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != c.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
            .sortedBy { it.label.lowercase() }
    }

    /** फ़ोन में लगे सभी ब्राउज़र (Chrome, Cromite, Chromium, Brave...) */
    private fun browsers(c: Context): Set<String> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER)
        return c.packageManager.queryIntentActivities(i, 0)
            .map { it.activityInfo.packageName }
            .toSet()
    }

    /** पहले पेज पर दिखने वाले ऐप: जाने-पहचाने + ब्राउज़र + जो पहले से चुने हुए हैं */
    fun suggested(c: Context, selected: Set<String>): List<AppItem> {
        val br = browsers(c)
        return launchable(c).filter { it.pkg in KNOWN || it.pkg in br || it.pkg in selected }
    }
}
