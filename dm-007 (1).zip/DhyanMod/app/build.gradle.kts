plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.selfcontrol.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.selfcontrol.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 7
        versionName = "7.0"
    }

    // हर बार एक ही चाबी से साइन: अपडेट पुराने ऐप के ऊपर इंस्टॉल हो जाएँगे, सेटिंग बनी रहेंगी
    signingConfigs {
        create("fixed") {
            storeFile = file("fixed.keystore")
            storePassword = "dhyanmod"
            keyAlias = "dhyanmod"
            keyPassword = "dhyanmod"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
