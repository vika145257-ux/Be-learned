package com.selfcontrol.app

import android.content.Context
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * जाँच के लिए: सर्विस ने क्या देखा और क्या किया, ताकि गड़बड़ पकड़ी जा सके।
 * सिर्फ़ ऐप का नाम और समय रखता है। स्क्रीन का टेक्स्ट कुछ नहीं, और यह फ़ोन से बाहर कहीं नहीं जाता।
 */
object Diag {
    @Volatile
    var connected = false

    @Volatile
    var events = 0

    @Volatile
    var hits = 0

    @Volatile
    var shown = 0

    @Volatile
    private var lastEvent = "-"

    @Volatile
    private var lastHit = "-"

    private val notes = mutableListOf<String>()

    private fun now(): String = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())

    fun seen(pkg: String) {
        events++
        lastEvent = pkg + " (" + now() + ")"
    }

    fun hit(pkg: String) {
        hits++
        lastHit = pkg + " (" + now() + ")"
    }

    @Synchronized
    fun note(s: String) {
        notes.add(now() + "  " + s)
        while (notes.size > 6) notes.removeAt(0)
    }

    @Synchronized
    fun text(c: Context): String {
        val conn = if (connected) "हाँ" else "नहीं"
        val ticked = Prefs.blocked(c).joinToString("\n  ")
        val recent = if (notes.isEmpty()) "-" else notes.joinToString("\n")
        return "फ़ोन: " + Build.MANUFACTURER + " " + Build.MODEL +
                ", Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")\n" +
                "सर्विस जुड़ी है: " + conn + "\n" +
                "अब तक के event: " + events + " | टिक वाले ऐप के: " + hits +
                " | वीडियो परत: " + shown + " बार\n" +
                "आख़िरी event: " + lastEvent + "\n" +
                "आख़िरी टिक वाला event: " + lastHit + "\n" +
                "पिछली बातें:\n" + recent + "\n" +
                "टिक वाले ऐप:\n  " + ticked
    }
}
