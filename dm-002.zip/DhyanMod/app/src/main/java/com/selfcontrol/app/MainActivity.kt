package com.selfcontrol.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private val pickCode = 21
    private val bg = Color.parseColor("#303030")
    private val txt = Color.parseColor("#E3E3E3")
    private val soft = Color.parseColor("#BDBDBD")

    private lateinit var col: LinearLayout
    private lateinit var appBox: LinearLayout
    private lateinit var videoCount: TextView
    private lateinit var svcNote: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(48), dp(20), dp(40))
        scroll.addView(col)

        col.addView(tv("ध्यान मोड़", 32f, txt, 0))

        // 1) ऐप चुनो
        col.addView(tv("1) कौन-से ऐप खुलने पर रोकना है:", 20f, txt, 32))
        appBox = LinearLayout(this)
        appBox.orientation = LinearLayout.VERTICAL
        appBox.setPadding(dp(8), dp(8), 0, 0)
        col.addView(appBox)
        addBtn(btn("+ और ऐप चुनो") { chooseMore() })

        // 2) वीडियो
        col.addView(tv("2) अपने वीडियो डालो:", 20f, txt, 32))
        videoCount = tv("", 18f, soft, 4)
        col.addView(videoCount)
        addBtn(btn("वीडियो जोड़ो") { pickVideos() })
        addBtn(btn("सारे वीडियो हटाओ") {
            Prefs.clearVideos(this)
            refreshVideos()
            Toast.makeText(this, "सारे वीडियो हटा दिए", Toast.LENGTH_SHORT).show()
        })

        // 3) सर्विस
        col.addView(tv("3) सर्विस चालू करो:", 20f, txt, 32))
        addBtn(btn("ACCESSIBILITY सेटिंग खोलो") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        svcNote = tv("", 16f, soft, 8)
        svcNote.setPadding(dp(8), dp(8), 0, 0)
        col.addView(svcNote)

        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        buildApps()
        refreshVideos()
        if (a11yOn()) {
            svcNote.text = "✅ सर्विस चालू है। चुना हुआ ऐप खोलते ही वीडियो चलेगी।"
            svcNote.setTextColor(Color.parseColor("#7CE38B"))
        } else {
            svcNote.text = "वहाँ 'ध्यान मोड़' ढूँढकर चालू करो।"
            svcNote.setTextColor(soft)
        }
    }

    private fun tv(text: String, size: Float, color: Int, top: Int): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        t.setPadding(0, dp(top), 0, 0)
        return t
    }

    private fun btn(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.textSize = 16f
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(Color.parseColor("#59595B"))
        b.setOnClickListener { onClick() }
        return b
    }

    private fun addBtn(b: Button) {
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(52)
        )
        lp.topMargin = dp(14)
        lp.leftMargin = dp(8)
        lp.rightMargin = dp(8)
        col.addView(b, lp)
    }

    private fun buildApps() {
        appBox.removeAllViews()
        val selected = Prefs.blocked(this)
        val shown = Apps.suggested(this, selected)
        if (shown.isEmpty()) {
            appBox.addView(tv("कोई जाना-पहचाना ऐप नहीं मिला। नीचे 'और ऐप चुनो' दबाओ।", 16f, soft, 8))
            return
        }
        for (app in shown) {
            val cb = CheckBox(this)
            cb.text = app.label
            cb.textSize = 18f
            cb.setTextColor(Color.WHITE)
            cb.buttonTintList = ColorStateList.valueOf(Color.parseColor("#80CBC4"))
            cb.setPadding(dp(8), dp(10), 0, dp(10))
            cb.isChecked = app.pkg in selected
            cb.setOnCheckedChangeListener { _, checked ->
                val s = Prefs.blocked(this).toMutableSet()
                if (checked) s.add(app.pkg) else s.remove(app.pkg)
                Prefs.setBlocked(this, s)
            }
            appBox.addView(cb)
        }
    }

    private fun chooseMore() {
        val all = Apps.launchable(this)
        val sel = Prefs.blocked(this).toMutableSet()
        val labels = all.map { it.label }.toTypedArray()
        val checked = BooleanArray(all.size) { all[it].pkg in sel }
        AlertDialog.Builder(this)
            .setTitle("और ऐप चुनो")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked ->
                if (isChecked) sel.add(all[which].pkg) else sel.remove(all[which].pkg)
            }
            .setPositiveButton("ठीक है") { _, _ ->
                Prefs.setBlocked(this, sel)
                buildApps()
            }
            .setNegativeButton("रद्द", null)
            .show()
    }

    private fun refreshVideos() {
        videoCount.text = "जोड़े गए वीडियो: ${Prefs.videos(this).size}"
    }

    private fun pickVideos() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .setType("video/*")
            .addCategory(Intent.CATEGORY_OPENABLE)
            .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(i, pickCode)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickCode || resultCode != RESULT_OK || data == null) return

        val uris = ArrayList<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (k in 0 until clip.itemCount) uris.add(clip.getItemAt(k).uri)
        } else {
            data.data?.let { uris.add(it) }
        }
        if (uris.isEmpty()) return

        Toast.makeText(this, "वीडियो जुड़ रही हैं...", Toast.LENGTH_SHORT).show()
        Thread {
            val dir = Prefs.videoDir(this)
            dir.mkdirs()
            var ok = 0
            val stamp = System.currentTimeMillis()
            for ((idx, uri) in uris.withIndex()) {
                try {
                    val out = File(dir, "v${stamp}_$idx.mp4")
                    val input = contentResolver.openInputStream(uri) ?: continue
                    input.use { ins -> out.outputStream().use { o -> ins.copyTo(o) } }
                    ok++
                } catch (e: Exception) {
                    // यह वीडियो नहीं जुड़ी, अगली पर चलो
                }
            }
            runOnUiThread {
                refreshVideos()
                val msg = if (ok > 0) "$ok वीडियो जुड़ गईं" else "वीडियो नहीं जुड़ पाई, दोबारा चुनो"
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return s.split(':').any { it.startsWith("$packageName/") }
    }
}
